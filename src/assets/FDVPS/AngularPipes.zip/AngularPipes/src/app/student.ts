export class Student{
    name: string;
    course: string;
    marks: number;
    DOB: Date;
    gender: string;
}